#include<iostream>
#include<forward_list>

using namespace std;

int main(){
    forward_list<int> lst1; // declaration of a list
    forward_list<int> :: iterator it; // iterator for list

    // assigning values into list.
    lst1.assign({10,20,30});

    for(it = lst1.begin(); it!= lst1.end(); ++it)
        cout << *it << " ";

    cout << endl;

    // using assign() method in other way
    lst1.assign(3,99);
    // assigning three elements of each value 99

    for(it = lst1.begin(); it!= lst1.end(); ++it)
    	cout << *it << " ";

    cout << endl;

    return 0;
}
