//labsol su20
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

class Cargo
{
private:
    string uldtype;
    string abbrev;
    string uldid;
    int aircraft;
    int weight;
    string destination;
public:
    ///Default constructor prototyped SU20
    Cargo();

    ///Full constructor prototype//
    Cargo(const string uldtype, const string abbrev, const string uldid, const int aircraft, const int weight, const string destination);

    ///Destructor prototype
    ~Cargo();
    ///Mutator (setters) prototypes
    void setuldtype(string);
    void setabbrev(string);
    void setuldid(string);
    void setaircraft(int);
    void setweight(int);
    void setdestination(string);

    ///Accessor (getters) prototypes
    string getuldtype() const;
    string getabbrev() const;
    string getuldid() const;
    int getaircraft() const;
    int getweight() const;
    string getdestination() const;

    input(Cargo &);
    output(Cargo &);
};


int main()
{
    Cargo *cPtr = new Cargo;
    cPtr->input(*cPtr);
    cPtr->output(*cPtr);
    delete cPtr;
    return 0;
}
    Cargo::Cargo()
    {
        uldtype = " ";
        abbrev = "XXX";
        uldid = "xxxxxIB";
        aircraft = 700;
        weight = 0;
        destination = " ";
    }
    Cargo::Cargo(const string type, const string abrv, const string id, const int craft, const int wt, const string dest)
    {
        uldtype = type;
        abbrev = abrv;
        uldid = id;
        aircraft = craft;
        weight = wt;
        destination = dest;
    }
    Cargo::~Cargo()
    {
        //delete ;
        cout << "\nCargo destructor called\n";
    }
    void Cargo::setuldtype(string type)
    {
        uldtype = type;
    }
    void Cargo::setabbrev(string abrv)
    {
        abbrev = abrv;
    }
    void Cargo::setuldid(string id)
    {
        uldid = id;
    }
    void Cargo::setaircraft(int air)
    {
        aircraft = air;
    }
    void Cargo::setweight(int wt)
    {
        weight = wt;
    }
    void Cargo::setdestination(string dest)
    {
        destination = dest;
    }
    string Cargo::getuldtype() const
    {
        return uldtype;
    }
    string Cargo::getabbrev() const
    {
        return abbrev;
    }
    string Cargo::getuldid() const
    {
        return uldid;
    }
    int Cargo::getaircraft() const
    {
        return aircraft;
    }
    int Cargo::getweight() const
    {
        return weight;
    }
    string Cargo::getdestination() const
    {
        return destination;
    }
    Cargo::output(Cargo &)
    {
        cout << setw(19) << "Unit load type: " << uldtype << endl;
        cout << setw(19) << "Unit abbreviation: " << abbrev << endl;
        cout << setw(19) << "Unit identifier: " << uldid << endl;
        cout << setw(19) << "Aircraft type: " << aircraft << endl;
        cout << setw(19) << "Unit weight: " << weight << endl;
        cout << setw(19) << "Destination code: " << destination << endl;
    }
    Cargo::input(Cargo &)
    {
        string type;
        string abrv;
        string id;
        int air;
        int wt;
        string dest;

        cout << "\nPlease input load information\n";
        cout << "Container or Pallet?  ";
        cin >> type;
        setuldtype(type);
        cout << "\nUnit abbreviation? ";
        cin >> abrv;
        cout << "\nUnit id?  ";
        cin >> id;
        setuldid(id);
        cout << "\nAircraft type?  ";
        cin >> air;
        setaircraft(air);
        cout << "\nLoaded weight?  ";
        cin >> wt;
        setweight(wt);
        cout << "\nDestination?  ";
        cin >> dest;
        setdestination(dest);
        cout << endl;
    }
