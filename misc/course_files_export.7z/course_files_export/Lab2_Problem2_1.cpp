/*
Problem 2.1 - Chapter 11: Introduction to structures
Declare a structure with a type name: Car
Create the following functions: main, input, output
*/
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

//Structure declaration
struct Car
{
    string reportingMark;   // a string of 5 or less upper case characters
    int carNumber;          // an int
    string kind;            // could be box, tank, flat or other
    bool loaded;            // a bool
    string destination;     // a string with a destination or the word NONE
};

// Function prototypes
void input(Car *cPtr);
void output(Car *cPtr);

int main()
{
    Car *cPtr;          // Define a Car pointer
    cPtr = new Car;     // Use new to obtain space for the data structure

    input(cPtr);      // Call input to get data
    output(cPtr);     // Call output to print data
    delete cPtr;      // Delete the space obtained using new
    return 0;
}
/************************ input ****************************
Read all the data from the user
After all the data has been read, put this data into the structure
Function accepts a structure pointer
*/
void input(Car *cPtr)
{
    // Local variables
    string rMark;   // a string of 5 or less upper case characters
    int cNumber;    // an int
    string knd;     // could be box, tank, flat or other
    bool load;      // a bool
    string dest;    // a string with a destination or the word NONE

    int len;        // Check a string of 5 or less characters

    // Read all the data from the user
    cout << "Enter reportingMark: ";
    getline(cin, rMark);
    len = rMark.length();
    // Check length
    while (len > 5)
    {
        cout << "Invalid! Enter reportingMark with 5 or less upper case characters: ";
        cin >> rMark;
        len = rMark.length();
    }
    for (int i = 0; i < int (rMark.length());  i++)
        rMark[i] = toupper(rMark[i]);
    cout << "Enter carNumber: ";
    cin >> cNumber;
    cout << "Enter kind (box, tank, flat or other): ";
    cin >> knd;
    cout << "Enter 'true' for load or 'false' for noload:  ";
    cin >> std::boolalpha >> load;
    cin.ignore();
    if (load)
    {
        cout << "Enter destination: ";
        getline(cin, dest);
    }
    else
        dest = "NONE";
    // Put all this data into the structure pointer
    cPtr->reportingMark = rMark; ///rather than (*cPtr).reportingMark = rMark;
    cPtr->carNumber = cNumber;
    cPtr->kind = knd;
    cPtr->loaded = load;
    cPtr->destination = dest;
}
/********************* output *************************
Print the data in a neat format
Function accepts a structure pointer
*/
void output(Car *cPtr)
{
    cout << "\n * Display the Car data *\n";
    cout << setw(15) << left << "ReportingMark: " << cPtr->reportingMark;
    cout << setw(16) << left <<"\nCarNumber: " << cPtr->carNumber;
    cout << setw(16) << left <<"\nKind: " << cPtr->kind;
    cout << setw(16) << left <<"\nLoaded: ";
    cout << std::boolalpha << cPtr->loaded;
    cout << setw(16) << left <<"\nDestination: " << cPtr->destination;
    cout << endl;
}

/* OUTPUT RESULT
Enter reportingMark: sppppppp
Invalid! Enter reportingMark with 5 or less upper case characters: sp
Enter carNumber: 34567
Enter kind (box, tank, flat or other): box
Enter 'true' for load or 'false' for noload:  true
Enter destination: Salt Lake City

 * Display the Car data *
ReportingMark: SP
CarNumber:     34567
Kind:          box
Loaded:        true
Destination:   Salt Lake City

Process returned 0 (0x0)   execution time : 22.902 s
Press any key to continue.


*/
