#include <iostream>
#include <string>
using namespace std;

class Cargo {
private:
    string uldtype;
    string uldid;
    int aircraft;
    int weight;
    string destination;
public:
    Cargo();
    Cargo(const string uldtype, const string uldid, const int aircraft, const int weight, const string destination);
    ~Cargo();
    void setuldtype();
    void setuldid();
    void setaircraft();
    void setweight();
    void setdestination();
    string getuldtype() const;
    string getuldid() const;
    int getaircraft() const;
    int getweight() const;
    string getdestination() const ;
    input();
    output();
};


int main() {
    string type;
    Cargo load1;
    load1.output();
    load1.input();
    load1.output();
    return 0;
}
    Cargo::Cargo()
    {
        uldtype = "";
        uldid = "00000IB";
        aircraft = 700;
        weight = 0;
        destination = "";
    }
    Cargo::Cargo(const string type, const string id, const int craft, const int wt, const string dest)
    {
        uldtype = type;
        uldid = id;
        aircraft = craft;
        weight = wt;
        destination = dest;
    }
    Cargo::~Cargo()
    {
        cout << "Cargo destructor called\n";
    }
    void setuldtype()
    {

    }
    void setuldid()
    {

    }
    void setaircraft()
    {

    }
    void setweight()
    {

    }
    void setdestination()
    {

    }
    string getuldtype()
    {

    }
    string getuldid()
    {

    }
    int getaircraft()
    {

    }
    int getweight()
    {

    }
    string getdestination()
    {

    }
    Cargo::output()
    {
        cout << uldtype << endl;
        cout << uldid << endl;
        cout << aircraft << endl;
        cout << weight << endl;
        cout << destination << endl;
    }
    Cargo::input()
    {

    }
