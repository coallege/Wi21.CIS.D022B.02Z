
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

//Class declaration
class Car
{
public:
    string reportingMark;   // a string of 5 or less upper case characters
    int carNumber;          // an int
    string kind;            // could be box, tank, flat or other
    bool loaded;            // a bool
    string destination;     // a string with a destination or the word NONE

public:
// Constructors
        Car()
        {
            reportingMark = "None";
            carNumber = 0;
            kind = "None";
            loaded = false;
            destination = "None";
        }

        Car(string rMark, int cNumber, string knd, bool load, string dest)
        {
            reportingMark = rMark;
            carNumber = cNumber;
            kind = knd;
            loaded = load;
            destination = dest;
        }

        // Destructor
        ~Car()
        {};

        // Mutator member function prototypes
        void setReportingMark(string rMark)
        {   reportingMark = rMark;}

        void setCarNumber(int cNumber)
        {   carNumber = cNumber;}

        void setKind(string knd)
        {   kind = knd;}

        void setLoaded(bool load)
        {   loaded = load;}

        void setDestination(string dest)
        {   destination = dest;}

        // Accessor member function prototypes
        string getReportingMark() const
        {   return reportingMark;}

        int getCarNumber() const
        {   return carNumber;}

        string getKind() const
        {   return kind;}

        bool getLoaded() const
        {   return loaded;}

        string getDestination() const
        {   return destination;}

        /* ******************** setUpCar ********************
        creates an object using a constructor that takes the reference parameters
            pointer to the object c1 returned.
        */
        Car* setUpCar(string rMark, int cNumber, string knd, bool load, string dest)
        {
            Car *c1 = new Car(rMark, cNumber, knd, load, dest);
            return c1;
        }
};

// Function prototypes
void input(string &rMark, int &cNumber, string &knd, bool &load, string &dest);
void output(Car *cPtr);

/********************** main ****************************/
int main()
{
    // Define five local variables.
    string rMark;   // string of 5 or less upper characters
    int cNumber;    // an int
    string knd;     // could be box, tank, flat or other
    bool load;      // a bool
    string dest;    // a string with a destination or the word NONE

    input(rMark, cNumber, knd, load, dest);      // Call input to read only the data
    Car *cPtr;        // Define a Car pointer
    cPtr = cPtr->setUpCar(rMark, cNumber, knd, load, dest);
    output(cPtr);     // Call output to print the data
    delete cPtr;      // Delete the object from memory
    return 0;
}
/********************** input ****************************
Read only the data from the user and call an additional
function named setUpCar which will put the data in the object.
Function accepts a Car class object pointer
*/
void input(string &rMark, int &cNumber, string &knd, bool &load, string &dest)
{
    int len;        // Check a string of 5 or less characters

    // Read all the data from the user
    cout << "Enter reportingMark: ";
    getline(cin, rMark);
    len = rMark.length();
    // Check length
    while (len > 5)
    {
        cout << "Invalid! Enter reportingMark with 5 or less upper case characters: ";
        cin >> rMark;
        len = rMark.length();
    }
    for (int i = 0; i < int (rMark.length());  i++)
        rMark[i] = toupper(rMark[i]);
    cout << "Enter carNumber: ";
    cin >> cNumber;
    cout << "Enter kind (box, tank, flat or other): ";
    cin >> knd;
    cout << "Enter 'true' for load or 'false' for noload:  ";
    cin >> std::boolalpha >> load;
    cin.ignore();
    if (load)
    {
        cout << "Enter destination: ";
        getline(cin, dest);
    }
    else
        dest = "NONE";
}
/********************* output *************************
Print the data in a neat format
Function accepts a Car class object pointer
*/
void output(Car *cPtr)
{
    cout << "\n * Display the Car data *\n";
    cout << setw(15) << left << "ReportingMark: " << cPtr->reportingMark;
    cout << setw(16) << left << "\nCarNumber: " << cPtr->carNumber;
    cout << setw(16) << left << "\nKind: " << cPtr->kind;
    cout << setw(16) << left <<"\nLoaded: ";
    cout << std::boolalpha << cPtr->loaded;
    cout << setw(16) << left << "\nDestination: " << cPtr->destination;
    cout << endl;
}

